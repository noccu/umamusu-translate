from enum import IntEnum


class SpriteMeshType(IntEnum):
    kSpriteMeshTypeFullRect = 0
    kSpriteMeshTypeTight = 1
